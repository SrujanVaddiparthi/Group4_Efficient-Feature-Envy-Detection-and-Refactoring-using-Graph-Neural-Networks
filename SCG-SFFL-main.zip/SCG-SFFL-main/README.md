# SCG-SFFL
Feature Envy Detection and Refactoring: SCG (SMOTE Call Graph) and its holistic approach SFFL (Symmetric Feature Fusion Learning)
